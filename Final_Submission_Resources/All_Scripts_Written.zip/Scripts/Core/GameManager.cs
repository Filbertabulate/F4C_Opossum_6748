using UnityEngine;
using UnityEngine.SceneManagement; // Required to restart the level

public class GameManager : MonoBehaviour
{
    [Header("Base References")]
    [Tooltip("Drag the main Player Base GameObject here")]
    public GameObject playerBase;
    [Tooltip("Drag the main Enemy Base GameObject here")]
    public GameObject enemyBase;

    // The container holding economy and spawn toolbars
    [Header("UI References")]
    public GameObject gameplayUI;
    public GameObject victoryPanel;
    public GameObject defeatPanel;

    private bool gameEnded = false;

    void Start()
    {
        // Ensure time flows normally when the scene starts, and the correct UI is showing
        Time.timeScale = 1f;
        gameEnded = false;

        if (gameplayUI != null) gameplayUI.SetActive(true);
        if (victoryPanel != null) victoryPanel.SetActive(false);
        if (defeatPanel != null) defeatPanel.SetActive(false);
    }

    void Update()
    {
        // If the game is already over, stop checking
        if (gameEnded) return;

        // Because HealthSystem uses Destroy(gameObject), the base will literally become 'null' when it dies.
        if (playerBase == null)
        {
            TriggerDefeat();
        }
        else if (enemyBase == null)
        {
            TriggerVictory();
        }
    }

    void TriggerVictory()
    {
        gameEnded = true;
        Debug.Log("F4C Opossum: Victory Achieved!");

        // Hide the playing UI and show the Victory screen
        if (gameplayUI != null) gameplayUI.SetActive(false);
        if (victoryPanel != null) victoryPanel.SetActive(true);

        // Freeze time so units stop moving and attacking
        Time.timeScale = 0f; 
    }

    void TriggerDefeat()
    {
        gameEnded = true;
        Debug.Log("F4C Opossum: Base Defeated!");

        // Hide the playing UI and show the Defeat screen
        if (gameplayUI != null) gameplayUI.SetActive(false);
        if (defeatPanel != null) defeatPanel.SetActive(true);

        // Freeze time
        Time.timeScale = 0f; 
    }

    // This method needs to be PUBLIC so the "Play Again" buttons can trigger it
    // Update it to return the MainMenu method
    public void ReturnToMainMenu()
    {
        // Unfreeze time before reloading, otherwise the new game will start frozen!
        Time.timeScale = 1f; 
        
        // Load Back the main Menu Scene, see if the transtion style is active instance, then use the
        // transition, else no transition.
        if (LevelManager.Instance != null)
        {
            LevelManager.Instance.LoadSceneNoLoadingBar("Main_Menu", "CrossFade");
        }
        // For scenarios where we start at game scene for testing
        else
        {
            Debug.LogWarning("LevelManager missing, loading Main_Menu directly.");
            SceneManager.LoadScene("Main_Menu");
        }
    }
}